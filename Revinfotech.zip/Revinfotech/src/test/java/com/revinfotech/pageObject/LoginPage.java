package com.revinfotech.pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {

	WebDriver ldriver;

	public LoginPage(WebDriver rdriver) {
		ldriver = rdriver;
		PageFactory.initElements(rdriver, this);
	}

	@FindBy(name = "email")
	@CacheLookup
	WebElement txtUserName;

	@FindBy(id = "passContainer")
	@CacheLookup
	WebElement txtPassword;

	@FindBy(name = "login")
	@CacheLookup
	WebElement btnLogin;

	@FindBy(className = "hu5pjgll op6gxeva")
	@CacheLookup
	WebElement menuBtn;

	@FindBy(id = "d2edcug0 hpfvmrgz qv66sw1b c1et5uql lr9zc1uh a8c37x1j keod5gw0 nxhoafnm aigsh9s9 d3f4x2em fe6kdd0r mau55g9w c8b282yb iv3no6db jq4qci2q a3bd9o3v ekzkrbhg oo9gr5id hzawbc8m")
	@CacheLookup
	WebElement btnLogout;

	public void setUserName(String uname) {
		txtUserName.sendKeys(uname);
	}

	public void setPassword(String pwd) {
		txtPassword.sendKeys(pwd);
	}

	public void clickSubmit() {
		btnLogin.click();
	}

	public void clickLogout() throws InterruptedException {
		menuBtn.click();
		Thread.sleep(3000);
		btnLogout.click();
	}

	public void allClear() throws InterruptedException {
		Thread.sleep(1000);
		txtUserName.clear();
		Thread.sleep(1000);
		txtPassword.clear();
		Thread.sleep(1000);
	}
}
